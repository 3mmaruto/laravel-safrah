<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Governorate;

class GovernorateController extends Controller
{
    public function index()
    {
        $governorates = Governorate::all(); // جيب كل المحافظات
        return response()->json($governorates); // رجعهم بصيغة JSON
    }
    //
}
